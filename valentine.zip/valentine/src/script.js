let messages = [
  "HAWWW 😳",
  "Shi Hai Yawrrr",
  "kood jaunga uppar se neeche mei",
  "AREYYYYY",
  "Okay ab bohot hogaya yeh!",
  "Just click yes already 😌"
];

let count = 0;
let lastMove = 0;

function yesClicked() {
  document.getElementById("card").innerHTML = `
    <h1>❤️</h1>
    <h2>YAYAYAYYA you're my valentine now!</h2>
    <p>Happy Valentine’s BAEBOO</p>
  `;
}

function noClicked() {
  const noBtn = document.getElementById("no");
  const now = Date.now();

  // prevent rapid jitter (cooldown 300ms)
  if (now - lastMove < 300) return;
  lastMove = now;

  // gentle movement
  const x = Math.random() * 80 - 40;
  const y = Math.random() * 40 - 20;
  noBtn.style.transform = `translate(${x}px, ${y}px)`;

  // change text
  noBtn.textContent = messages[count % messages.length];
  count++;
}

